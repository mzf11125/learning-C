#include<stdio.h>
#include<string.h>

struct presenter{
	char nama[105];
	int age;
	int point;
};

int main(){
	FILE *fp = fopen("testdata.in","r");
	//Prinsip Saya(Trainer) : Baca filenya bener" per baris
	int n,x;
	fscanf(fp,"%d %d\n",&n,&x);
	struct presenter datapresenter[n];
	//Buar cek
//	printf("%d %d",n,x);
	for(int i=0;i<n;i++){
		fscanf(fp,"%[^#]#%d#%d\n",datapresenter[i].nama,&datapresenter[i].age,&datapresenter[i].point);
//		printf("%s %d %d\n",datapresenter[i].nama,datapresenter[i].age,datapresenter[i].point);
	}
	
	if(x==1){
		for(int i=0;i<n-1;i++){
			for(int j = i+1 ;j<n;j++){
				if(strcmp(datapresenter[i].nama,datapresenter[j].nama)>0){
					struct presenter temp = datapresenter[i];
					datapresenter[i] = datapresenter[j];
					datapresenter[j] = temp;
				}
			}
		}
	}else if(x==2){
		for(int i=0;i<n-1;i++){
			for(int j = i+1 ;j<n;j++){
				if(datapresenter[i].age > datapresenter[j].age){
					struct presenter temp = datapresenter[i];
					datapresenter[i] = datapresenter[j];
					datapresenter[j] = temp;
				}
			}
		}		
	}else{
		for(int i=0;i<n-1;i++){
			for(int j = i+1 ;j<n;j++){
				if(datapresenter[i].point > datapresenter[j].point){
					struct presenter temp = datapresenter[i];
					datapresenter[i] = datapresenter[j];
					datapresenter[j] = temp;
				}
			}
		}		
	}
	
	for(int i=0;i<n;i++){
		printf("%s %d %d\n",datapresenter[i].nama,datapresenter[i].age,datapresenter[i].point);
	}

	
	fclose(fp);
	return 0;
}

