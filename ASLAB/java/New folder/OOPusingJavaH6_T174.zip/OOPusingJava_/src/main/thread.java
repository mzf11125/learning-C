package main;

public class thread extends Thread{
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}
}
