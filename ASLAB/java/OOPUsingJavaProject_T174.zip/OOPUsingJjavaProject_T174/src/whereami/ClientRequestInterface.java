package whereami;

public interface ClientRequestInterface {
	
}
