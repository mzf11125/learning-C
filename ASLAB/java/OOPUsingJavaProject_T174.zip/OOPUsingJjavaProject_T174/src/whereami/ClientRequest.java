package whereami;

public class ClientRequest {

}
