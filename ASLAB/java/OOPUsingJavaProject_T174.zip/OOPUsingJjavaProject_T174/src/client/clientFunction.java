package client;

public class clientFunction {
	public void client() {
		
	}
	
	
}
