package auth;

public class Authmain {
	protected String username; 
	protected String password;
	
	public Authmain(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	
	
	
}
