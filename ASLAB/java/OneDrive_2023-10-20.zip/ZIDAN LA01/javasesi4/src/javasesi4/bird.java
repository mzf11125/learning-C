package javasesi4;

public class bird extends animal{

	public bird(String name, int age) {
		super(name, age);
		
	}
	
	public void fly() {
		System.out.println(this.name + "Fly.........");
	}
	
	

}
