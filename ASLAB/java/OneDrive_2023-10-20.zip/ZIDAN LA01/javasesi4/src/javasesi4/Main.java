package javasesi4;



public class Main {

	public Main() {
//		animal hewan = new animal("Doggy", 2);
//		hewan.eat();
//		
//		String nama = new String("CL");		
//		bird bird = new bird("Pipit", 12);
//		bird.fly();
//		bird.eat();
//		fish fish = new fish("Nemo", 15, "Hiu");
//		fish.swim();
//		fish.eat();
//		fish.type();
		
//		animal hewan1 = new animal("Kucing", 2);
//		animal hewan2 = new animal("Rusa", 3);
//		
//		hewan1.warnaKulit = "Biru";
//		
//		System.out.println(hewan2.warnaKulit);
//		animal.bengong();
		
//		final int number = 10; // Final cannot be changed
//		number = 12;
		
//		final int number 
//		final String 
	}

	public static void main(String[] args) {
		new Main();

	}
}
//Animal = Superclass
//Age
//function eat
//burung = function
//-terbang





//1. Single inhertence 
//Class A -> class B
//
//Manusia -> subclass
//|             |
//kaki    tangan

//3. Multiclass
//Class A 
//  |
//Class b
//  |
//Class C
//
//4.Multiple
//Class A 
// /       \
//Class B  Class C
// \          /
//Class D



//-Composition: Subclass kepemilikan oleh supperclass, hubungan bagian
//Example 1
// manusia 
// /   \ 
//kaki tangan
//Example 2
// Mobil
// /    \
//Mesin warna

//- Agregation: Bukan dari bagian animalnya sendiri, hubungan sifat bukan bagian  

//Animal
// /    \ 
//Bird Animal
